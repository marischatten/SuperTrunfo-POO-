package classe;

public class Carta {
	
	double[] atributo = new double[4];  
	String nomePersonagem;
	boolean superTrunfo = false;  
	String grupo ;
	


/*Atributos
	float Altura;            //Metros
	int Comprimento;       //Metros
	double int Peso;       //Kg
	int Viveu:             //MilhÃµes de anos
	
*/
	
}